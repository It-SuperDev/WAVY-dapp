import { createContext } from 'react';

const ThemeContext = createContext(undefined);

export { ThemeContext };
