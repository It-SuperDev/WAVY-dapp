import { createContext } from 'react';

const APIContext = createContext(undefined);

export { APIContext };
