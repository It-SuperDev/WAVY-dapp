import { Outlet } from 'react-router-dom';

const CompactLayout = () => (
    <div>
        <Outlet />
    </div>
);

export default CompactLayout;
